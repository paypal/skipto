var Wordpress =	{
		"settings": {
			"skipTo": {
				"headings": "h1 ,h2, h3",
				"landmarks": "[role=main],[role=search]",
				"accesskey": "0",
				"wrap": "true",
				"visibility": "onFocus"
			}
		}
};
